# 🔗 LinkedIn Post (Ready to Copy)

Below are three variants — pick whichever fits your voice. Edit the bracketed parts before posting.

---

## Variant 1 — Direct & Professional

🛡️ Just wrapped up a hands-on lab on **TryHackMe**: *Rpnessusredux — Walkthrough & Notes*.

What I worked on:
• Enumerate the target system using common reconnaissance tools
• Identify and exploit vulnerabilities in the target environment
• Capture user and root flags to complete the room

Tools used: Nmap · Gobuster / Dirb · Burp Suite · Metasploit · Linux command line

Biggest takeaway: how to approach an unknown target system methodically.

Full writeup with screenshots, queries, and MITRE ATT&CK mappings is in my GitHub portfolio 👉 [link]

#Cybersecurity #BlueTeam #TryHackMe #PortfolioProject #LearningInPublic

---

## Variant 2 — Story-Driven (more engagement)

A few weeks ago I couldn't have told you what *Network reconnaissance* really meant.

Today I just finished a hands-on lab on **TryHackMe** where I had to actually do it — not just read about it.

Here's what I built / broke / learned:
→ Enumerate the target system using common reconnaissance tools
→ Identify and exploit vulnerabilities in the target environment
→ Mapped everything to MITRE ATT&CK so I understand the *why*

The lesson I'll carry forward: how to approach an unknown target system methodically.

Sharing the full writeup so other beginners can see what this looks like in practice 👇
[link to your GitHub]

#Cybersecurity #LearningInPublic #BlueTeam #InfoSec

---

## Variant 3 — Short & Punchy

New project up. 🛡️

✅ TryHackMe lab complete
✅ Nmap, Gobuster / Dirb, Burp Suite
✅ MITRE ATT&CK mapped
✅ Documented end-to-end in GitHub

Recruiter-ready writeup → [link]

#Cybersecurity #TryHackMe #Portfolio

---

## 📌 Posting tips

1. Post during weekday business hours (10am–2pm in your timezone gets best reach).
2. Include the GitHub link, but don't lead with it — LinkedIn deprioritizes link-heavy posts.
3. Add one screenshot from your lab as the post image — visuals 5x engagement.
4. Reply to every comment in the first hour — it boosts the algorithm.
5. Tag people who taught you (the course instructor, the platform's official page) — they often reshare.

# 💼 Resume Bullets

These are pre-written, action-verb-first, results-focused bullets. Drop them straight into your resume.

---

## Standard Version (use these as-is)

- Completed Rpnessusredux demonstrating offensive security methodology end-to-end
- Performed network and service enumeration using Nmap and directory brute-forcing tools
- Documented exploitation chain and remediation recommendations in GitHub portfolio
- Mapped attack chain to MITRE ATT&CK tactics and techniques

---

## Punchy Version (shorter, for tight resume real estate)

- Completed Rpnessusredux
- Performed network and service enumeration using Nmap and directory brute-forcing tools
- Documented exploitation chain and remediation recommendations
- Mapped attack chain to MITRE ATT&CK tactics and techniques

---

## ✏️ Customization tips

1. **Add a number wherever possible.** "Wrote 12 KQL detection rules" beats "Wrote KQL detection rules."
2. **Lead with the action verb.** Built, deployed, investigated, detected, automated, hardened.
3. **End with the outcome.** "...resulting in X" or "...demonstrating Y skill" makes recruiters slow down.
4. **Match the job description's keywords.** If a job says "SIEM," use "SIEM" — not just "Splunk."

---

## 📋 Where to put these

- **Projects** section of your resume (preferred for students/career-changers)
- **Skills** section (as supporting evidence)
- **LinkedIn → Featured** (link to the GitHub repo)
- **Cover letter** (paraphrased, not copy-pasted)

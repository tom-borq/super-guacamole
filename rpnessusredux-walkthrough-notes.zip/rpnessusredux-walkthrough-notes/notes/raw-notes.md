# 📝 Raw Notes

> Unpolished notes from working through this lab. The README is the polished story; this file is the messy reality.

**Lab:** https://tryhackme.com/r/room/rpnessusredux
**Date started:** 2026-11-11
**Platform:** TryHackMe

---

## Initial impressions

Prepared and applied concepts for vulnerability scanning with nessus.

---

## Commands & queries I ran

```
# paste anything useful here as you go
```

---

## Things that confused me

- _Add anything you got stuck on. Future-you will be grateful._

---

## Aha moments

- _The little realizations that clicked while doing the lab. These are gold for blog posts later._

---

## Questions for follow-up

- _Stuff you want to research more deeply after the lab._

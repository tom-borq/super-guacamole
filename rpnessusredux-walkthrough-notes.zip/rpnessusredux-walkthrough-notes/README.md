# 🛡️ Rpnessusredux — Walkthrough & Notes

> TryHackMe room writeup with methodology, tools, and lessons learned.

![Platform](https://img.shields.io/badge/platform-TryHackMe-39ff7a?style=flat-square)
![Status](https://img.shields.io/badge/status-complete-39ff7a?style=flat-square)
![Date](https://img.shields.io/badge/date-2026-11-11-blue?style=flat-square)

---

## 📌 Overview

This repository documents my hands-on completion of **Rpnessusredux — Walkthrough & Notes** on **TryHackMe**.
It includes the methodology I followed, tools I used, evidence I captured, and the skills I demonstrated.

**Lab URL:** https://tryhackme.com/r/room/rpnessusredux

---

## 🎯 Objectives

- Enumerate the target system using common reconnaissance tools
- Identify and exploit vulnerabilities in the target environment
- Capture user and root flags to complete the room
- Document findings in a clear, reproducible writeup

---

## 🧰 Tools & Technologies

`Nmap` · `Gobuster / Dirb` · `Burp Suite` · `Metasploit` · `Linux command line` · `TryHackMe AttackBox`

---

## 🧠 Security Concepts Demonstrated

- Network reconnaissance
- Service enumeration
- Vulnerability exploitation
- Privilege escalation
- Post-exploitation

---

## 🏗️ Architecture / Lab Environment

> See `diagrams/architecture.md` for a description of the lab setup.
> Add a diagram image at `diagrams/architecture.png` (you can draw one in [draw.io](https://app.diagrams.net/) or [Excalidraw](https://excalidraw.com/) for free).

![Architecture](diagrams/architecture.png)

---

## 🪜 Walkthrough

> Replace this section with your actual step-by-step walkthrough.
> Use the placeholders below as a starting structure.

### Step 1 — Setup & Recon
Describe how you set up the environment and what initial reconnaissance you performed.

### Step 2 — Investigation / Exploitation
Describe the main work of the lab — the queries you ran, exploits you tried, or controls you configured.

### Step 3 — Validation
Describe how you confirmed the work was correct (alerts fired, exploit succeeded, control blocked the attack, etc).

### Step 4 — Cleanup & Reflection
Describe how you ended the lab and what you'd do differently next time.

### 📝 My Lab Notes

> The following are my raw notes captured during the lab.

```
Prepared and applied concepts for vulnerability scanning with nessus.
```

---

## 📸 Screenshots

> Drop matching PNG/JPG files into the `screenshots/` folder using the filenames below.

### Nmap Scan

> Initial Nmap scan revealing open ports

![Nmap Scan](screenshots/nmap-scan.png)

### Enumeration

> Service / directory enumeration results

![Enumeration](screenshots/enumeration.png)

### Exploit

> Successful exploitation step

![Exploit](screenshots/exploit.png)

### User Flag

> User flag captured

![User Flag](screenshots/user-flag.png)

### Root Flag

> Root / system flag captured

![Root Flag](screenshots/root-flag.png)

---

## 🎯 MITRE ATT&CK Mapping

| ID | Tactic / Technique | How it appears in this lab |
|----|--------------------|----------------------------|
| `TA0043` | Reconnaissance | Active scanning of target services |
| `TA0001` | Initial Access | Exploitation of public-facing application |
| `TA0004` | Privilege Escalation | Abuse of misconfigured permissions |
| `T1059` | Command and Scripting Interpreter | Use of shell access for execution |

---

## 🧠 What I Learned

- How to approach an unknown target system methodically
- The importance of thorough enumeration before exploitation
- How small misconfigurations chain into full system compromise
- Why clear documentation is as valuable as the technical work itself

---

## 🚨 Common Mistakes I Avoided (or Made)

- _Add 2–3 mistakes you ran into and how you solved them. Recruiters love this section — it shows reflection._

---

## 🛠️ Skills Gained

- Nmap
- Gobuster / Dirb
- Burp Suite
- Metasploit
- Network reconnaissance
- Service enumeration
- Vulnerability exploitation

---

## 📚 Suggested Next Projects

- Attempt a harder room in the same skill path
- Try the same techniques on a Hack The Box machine
- Build a detection rule for the exploited vulnerability
- Write a blog post explaining the room in your own words

---

## 💼 Resume Bullets

> Copy/paste these straight into your resume:

- Completed Rpnessusredux demonstrating offensive security methodology end-to-end
- Performed network and service enumeration using Nmap and directory brute-forcing tools
- Documented exploitation chain and remediation recommendations in GitHub portfolio
- Mapped attack chain to MITRE ATT&CK tactics and techniques

---

## 🔗 References

- [TryHackMe](https://tryhackme.com/r/room/rpnessusredux)
- [MITRE ATT&CK Framework](https://attack.mitre.org/)
- [GitHub Markdown Guide](https://docs.github.com/en/get-started/writing-on-github)

---

## 👤 About Me

I'm **Tom Q**, a cybersecurity student building public proof-of-skill through hands-on labs and detailed writeups.

- 🌐 GitHub: [@https://github.com/tom-borq](https://github.com/https://github.com/tom-borq)
- 📂 More projects: see my [pinned repositories](https://github.com/https://github.com/tom-borq)

---

## 📝 License

MIT — see [LICENSE](LICENSE).

---

> 🛠️ Generated with [Portfolio Forge](https://github.com/) — a free PWA that turns lab URLs into GitHub portfolio repos.

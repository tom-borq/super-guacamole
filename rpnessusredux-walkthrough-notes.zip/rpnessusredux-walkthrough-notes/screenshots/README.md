# 📸 Screenshots

Drop your PNG / JPG screenshots in this folder.

**Important:** the filenames in the parent README are case-sensitive. Use exactly these names:

- `nmap-scan.png` — Initial Nmap scan revealing open ports
- `enumeration.png` — Service / directory enumeration results
- `exploit.png` — Successful exploitation step
- `user-flag.png` — User flag captured
- `root-flag.png` — Root / system flag captured

---

## 📐 Screenshot tips

- Use **PNG** for UI screenshots, **JPG** for photos.
- Keep file size under 1 MB each. Use [TinyPNG](https://tinypng.com/) to compress.
- Crop to remove personal info (your real name in title bars, etc).
- Use a clean dark theme if possible — looks more professional.
- For terminal screenshots, [Carbon](https://carbon.now.sh/) makes them gorgeous.
